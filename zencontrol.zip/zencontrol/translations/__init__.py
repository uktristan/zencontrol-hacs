"""Translation files for ZenControl integration."""
# Empty file - translations are loaded via strings.json