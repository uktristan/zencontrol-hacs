"""Platform implementations for ZenControl integration."""
# Empty file - platforms are loaded individually